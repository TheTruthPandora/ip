# ip

The script in index.py file is a python script to show visitor's public ip address. The file index.py is under the api folder which is required to run at Vercel site. 

It can be run as a serverless app from serverless app hosting provider, such as vercel, Netlify, Heroku, or replit. 

or you can run it from local:
python3 index.py


# Deploy to vercel

Demo: https://ip.51sec.org/api
